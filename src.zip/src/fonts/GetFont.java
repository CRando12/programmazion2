/*
************************
*  HEADER ESCAPE ROOM  *
*   Barrile & Allegra  *
************************
*/

package fonts;

import java.awt.Font;
import java.awt.FontFormatException;
import java.awt.GraphicsEnvironment;
import java.io.File;
import java.io.IOException;
import java.nio.file.Path;


public class GetFont {
    
    private static Font FontName;
    private String pathStr;
    private Path path;
    
    public GetFont(String fontsource, Float dimension)
    {
        try {
            
            File path = new File("./src/fonts/" + fontsource);
            pathStr = path.getAbsolutePath();

            FontName = Font.createFont(Font.TRUETYPE_FONT, new File(pathStr)).deriveFont(dimension);
            GraphicsEnvironment ge = GraphicsEnvironment.getLocalGraphicsEnvironment();
            ge.registerFont(FontName);
        } catch (IOException|FontFormatException e) {
            System.out.println("Non è stato possibile caricare il font \"" + pathStr + "\"");
        }
    }
    
    public static Font GetThisFont()
    {
        return FontName;
    }
    
}